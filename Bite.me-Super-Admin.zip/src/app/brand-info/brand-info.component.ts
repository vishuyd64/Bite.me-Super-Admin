import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brand-info',
  templateUrl: './brand-info.component.html',
  styleUrls: ['./brand-info.component.scss']
})
export class BrandInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
