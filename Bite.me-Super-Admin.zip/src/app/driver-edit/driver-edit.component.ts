import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-edit',
  templateUrl: './driver-edit.component.html',
  styleUrls: ['./driver-edit.component.scss']
})
export class DriverEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
