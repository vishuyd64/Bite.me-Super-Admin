import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cuisine-manangement',
  templateUrl: './cuisine-manangement.component.html',
  styleUrls: ['./cuisine-manangement.component.scss']
})
export class CuisineManangementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
