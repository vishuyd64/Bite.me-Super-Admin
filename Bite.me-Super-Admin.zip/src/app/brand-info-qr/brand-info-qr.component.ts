import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brand-info-qr',
  templateUrl: './brand-info-qr.component.html',
  styleUrls: ['./brand-info-qr.component.scss']
})
export class BrandInfoQrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
