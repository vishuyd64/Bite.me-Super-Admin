import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eod-report',
  templateUrl: './eod-report.component.html',
  styleUrls: ['./eod-report.component.scss']
})
export class EodReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
