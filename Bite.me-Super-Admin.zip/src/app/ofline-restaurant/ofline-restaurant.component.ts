import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ofline-restaurant',
  templateUrl: './ofline-restaurant.component.html',
  styleUrls: ['./ofline-restaurant.component.scss']
})
export class OflineRestaurantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
