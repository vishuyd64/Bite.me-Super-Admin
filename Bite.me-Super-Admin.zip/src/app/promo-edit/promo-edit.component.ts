import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promo-edit',
  templateUrl: './promo-edit.component.html',
  styleUrls: ['./promo-edit.component.scss']
})
export class PromoEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
