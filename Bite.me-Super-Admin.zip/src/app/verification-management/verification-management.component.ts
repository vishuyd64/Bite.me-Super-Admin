import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verification-management',
  templateUrl: './verification-management.component.html',
  styleUrls: ['./verification-management.component.scss']
})
export class VerificationManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
