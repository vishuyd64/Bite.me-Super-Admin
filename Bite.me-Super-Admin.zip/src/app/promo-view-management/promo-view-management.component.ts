import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promo-view-management',
  templateUrl: './promo-view-management.component.html',
  styleUrls: ['./promo-view-management.component.scss']
})
export class PromoViewManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
