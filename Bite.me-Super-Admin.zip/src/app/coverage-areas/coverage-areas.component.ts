import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coverage-areas',
  templateUrl: './coverage-areas.component.html',
  styleUrls: ['./coverage-areas.component.scss']
})
export class CoverageAreasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
