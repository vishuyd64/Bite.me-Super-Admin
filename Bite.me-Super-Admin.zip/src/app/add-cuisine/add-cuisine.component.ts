import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-cuisine',
  templateUrl: './add-cuisine.component.html',
  styleUrls: ['./add-cuisine.component.scss']
})
export class AddCuisineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
