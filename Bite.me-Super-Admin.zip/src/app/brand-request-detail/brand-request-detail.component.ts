import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brand-request-detail',
  templateUrl: './brand-request-detail.component.html',
  styleUrls: ['./brand-request-detail.component.scss']
})
export class BrandRequestDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
