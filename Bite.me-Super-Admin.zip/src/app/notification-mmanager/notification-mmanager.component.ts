import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notification-mmanager',
  templateUrl: './notification-mmanager.component.html',
  styleUrls: ['./notification-mmanager.component.scss']
})
export class NotificationMmanagerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
