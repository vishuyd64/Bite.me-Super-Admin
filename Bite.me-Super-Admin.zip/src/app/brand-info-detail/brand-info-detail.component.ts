import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brand-info-detail',
  templateUrl: './brand-info-detail.component.html',
  styleUrls: ['./brand-info-detail.component.scss']
})
export class BrandInfoDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
