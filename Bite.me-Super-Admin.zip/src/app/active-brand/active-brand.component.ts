import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-brand',
  templateUrl: './active-brand.component.html',
  styleUrls: ['./active-brand.component.scss']
})
export class ActiveBrandComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
