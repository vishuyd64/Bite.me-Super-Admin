import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner-edit',
  templateUrl: './banner-edit.component.html',
  styleUrls: ['./banner-edit.component.scss']
})
export class BannerEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
