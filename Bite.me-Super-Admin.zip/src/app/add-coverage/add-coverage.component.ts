import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-coverage',
  templateUrl: './add-coverage.component.html',
  styleUrls: ['./add-coverage.component.scss']
})
export class AddCoverageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
