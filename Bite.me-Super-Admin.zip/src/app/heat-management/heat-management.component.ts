import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heat-management',
  templateUrl: './heat-management.component.html',
  styleUrls: ['./heat-management.component.scss']
})
export class HeatManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
