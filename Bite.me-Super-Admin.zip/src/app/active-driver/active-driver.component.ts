import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-driver',
  templateUrl: './active-driver.component.html',
  styleUrls: ['./active-driver.component.scss']
})
export class ActiveDriverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
