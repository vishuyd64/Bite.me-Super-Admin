import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-driver',
  templateUrl: './new-driver.component.html',
  styleUrls: ['./new-driver.component.scss']
})
export class NewDriverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
