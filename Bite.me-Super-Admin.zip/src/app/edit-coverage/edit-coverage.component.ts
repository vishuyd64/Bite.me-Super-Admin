import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-coverage',
  templateUrl: './edit-coverage.component.html',
  styleUrls: ['./edit-coverage.component.scss']
})
export class EditCoverageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
