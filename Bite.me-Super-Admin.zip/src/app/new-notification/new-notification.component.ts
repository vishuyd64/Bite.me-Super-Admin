import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-notification',
  templateUrl: './new-notification.component.html',
  styleUrls: ['./new-notification.component.scss']
})
export class NewNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
