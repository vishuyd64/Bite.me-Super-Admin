import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brand-management',
  templateUrl: './brand-management.component.html',
  styleUrls: ['./brand-management.component.scss']
})
export class BrandManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
