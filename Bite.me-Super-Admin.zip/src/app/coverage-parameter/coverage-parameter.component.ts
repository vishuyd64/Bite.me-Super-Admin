import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coverage-parameter',
  templateUrl: './coverage-parameter.component.html',
  styleUrls: ['./coverage-parameter.component.scss']
})
export class CoverageParameterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
