import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-performance-report',
  templateUrl: './performance-report.component.html',
  styleUrls: ['./performance-report.component.scss']
})
export class PerformanceReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
