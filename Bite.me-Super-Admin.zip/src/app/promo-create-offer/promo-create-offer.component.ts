import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promo-create-offer',
  templateUrl: './promo-create-offer.component.html',
  styleUrls: ['./promo-create-offer.component.scss']
})
export class PromoCreateOfferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
