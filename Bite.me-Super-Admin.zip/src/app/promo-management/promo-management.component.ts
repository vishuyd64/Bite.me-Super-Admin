import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promo-management',
  templateUrl: './promo-management.component.html',
  styleUrls: ['./promo-management.component.scss']
})
export class PromoManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
