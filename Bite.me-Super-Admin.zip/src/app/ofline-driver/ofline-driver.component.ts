import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ofline-driver',
  templateUrl: './ofline-driver.component.html',
  styleUrls: ['./ofline-driver.component.scss']
})
export class OflineDriverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
