import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-store',
  templateUrl: './active-store.component.html',
  styleUrls: ['./active-store.component.scss']
})
export class ActiveStoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
